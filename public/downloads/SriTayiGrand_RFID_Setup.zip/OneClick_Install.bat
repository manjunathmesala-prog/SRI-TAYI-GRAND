@echo off
title Sri Tayi Grand - One-Click RFID Installer
echo Installing Sri Tayi Grand RFID Bridge...
start "" "%~dp0SriTayiGrand_RFID_Setup.exe"
